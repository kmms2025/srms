const API_URL = 'http://localhost:8080/api';

// Check URL params on load
window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const role = urlParams.get('role');
    if (role === 'student') {
        switchRegTab('student');
    } else {
        switchRegTab('teacher');
    }
};

function switchRegTab(role) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`.tab-btn[onclick="switchRegTab('${role}')"]`).classList.add('active');

    document.getElementById('teacher-reg').classList.add('hidden');
    document.getElementById('student-reg').classList.add('hidden');
    document.getElementById(`${role}-reg`).classList.remove('hidden');
}

async function registerTeacher(event) {
    event.preventDefault();

    const teacherId = document.getElementById('reg-teacher-id').value;
    const password = document.getElementById('reg-teacher-password').value;
    const confirm = document.getElementById('reg-teacher-confirm').value;

    if (password !== confirm) {
        document.getElementById('teacher-reg-msg').innerText = 'Passwords do not match!';
        document.getElementById('teacher-reg-msg').style.color = 'red';
        return;
    }

    try {
        const res = await fetch(`${API_URL}/register_teacher`, {
            method: 'POST',
            body: JSON.stringify({ teacherId: teacherId, password: password })
        });
        const data = await res.json();

        if (res.ok) {
            document.getElementById('teacher-reg-msg').innerText = 'Registration successful! Redirecting to login...';
            document.getElementById('teacher-reg-msg').style.color = '#2ecc71';
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        } else {
            document.getElementById('teacher-reg-msg').innerText = data.error || 'Registration failed';
            document.getElementById('teacher-reg-msg').style.color = 'red';
        }
    } catch (e) {
        document.getElementById('teacher-reg-msg').innerText = 'Connection Error';
        document.getElementById('teacher-reg-msg').style.color = 'red';
    }
}

async function registerStudent(event) {
    event.preventDefault();

    const rollNo = document.getElementById('reg-roll').value;
    const name = document.getElementById('reg-name').value;
    const dob = document.getElementById('reg-dob').value;

    try {
        const res = await fetch(`${API_URL}/register_student`, {
            method: 'POST',
            body: JSON.stringify({
                rollNo: rollNo,
                name: name,
                dateOfBirth: dob,
                physics: 0,
                chemistry: 0,
                math: 0
            })
        });
        const data = await res.json();

        if (res.ok) {
            // Calculate password to show user
            const dobParts = dob.split('-');
            const password = dobParts[2] + dobParts[1] + dobParts[0];

            document.getElementById('student-reg-msg').innerText = `Registration successful! Your password is: ${password}. Redirecting to login...`;
            document.getElementById('student-reg-msg').style.color = '#2ecc71';
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 4000);
        } else {
            document.getElementById('student-reg-msg').innerText = data.error || 'Registration failed';
            document.getElementById('student-reg-msg').style.color = 'red';
        }
    } catch (e) {
        document.getElementById('student-reg-msg').innerText = 'Connection Error';
        document.getElementById('student-reg-msg').style.color = 'red';
    }
}
