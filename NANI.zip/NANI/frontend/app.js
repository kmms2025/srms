const API_URL = 'http://localhost:8080/api';
let chartInstance = null;

function switchTab(role) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`.tab-btn[onclick="switchTab('${role}')"]`).classList.add('active');

    document.getElementById('teacher-login').classList.add('hidden');
    document.getElementById('student-login').classList.add('hidden');
    document.getElementById(`${role}-login`).classList.remove('hidden');
    document.getElementById('login-error').innerText = '';

    // Update register link
    const registerLink = document.getElementById('register-link');
    if (registerLink) {
        registerLink.href = `register.html?role=${role}`;
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
    // Show target section
    document.getElementById(sectionId).classList.add('active');

    // Update sidebar active state
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    // Note: This assumes the clicked element called this function. 
    // For simplicity, we can match by onclick attribute or just rely on the user clicking.
    // A better way is to pass 'this' or look up the corresponding link.
    const activeLink = Array.from(document.querySelectorAll('.nav-item')).find(link => link.getAttribute('onclick').includes(sectionId));
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // Refresh data based on section
    if (sectionId === 'statistics-section') {
        loadStatistics();
    } else if (sectionId === 'all-students-section') {
        loadAllStudents();
    }
}

async function teacherLogin() {
    const teacherId = document.getElementById('teacher-id').value.trim();
    const password = document.getElementById('teacher-password').value.trim();

    if (!teacherId || !password) {
        document.getElementById('login-error').innerText = 'Please enter both Teacher ID and Password';
        return;
    }

    try {
        const res = await fetch(`${API_URL}/login`, {
            method: 'POST',
            body: JSON.stringify({ role: 'teacher', teacherId: teacherId, password: password })
        });
        const data = await res.json();

        if (res.ok) {
            document.getElementById('login-section').classList.add('hidden');
            document.getElementById('teacher-dashboard').classList.remove('hidden');
            loadAllStudents();
            loadStatistics();
        } else {
            document.getElementById('login-error').innerText = data.error;
        }
    } catch (e) {
        document.getElementById('login-error').innerText = 'Connection Error';
    }
}

async function studentLogin() {
    const rollNo = document.getElementById('student-roll').value.trim();
    const password = document.getElementById('student-password').value.trim();

    if (!rollNo || !password) {
        document.getElementById('login-error').innerText = 'Please enter both Roll Number and Password';
        return;
    }

    try {
        const res = await fetch(`${API_URL}/login`, {
            method: 'POST',
            body: JSON.stringify({ role: 'student', rollNo: rollNo, password: password })
        });
        const data = await res.json();

        if (res.ok) {
            document.getElementById('login-section').classList.add('hidden');
            document.getElementById('student-dashboard').classList.remove('hidden');
            loadStudentData(rollNo);
        } else {
            document.getElementById('login-error').innerText = data.error;
        }
    } catch (e) {
        document.getElementById('login-error').innerText = 'Connection Error';
    }
}

function logout() {
    document.getElementById('teacher-dashboard').classList.add('hidden');
    document.getElementById('student-dashboard').classList.add('hidden');
    document.getElementById('login-section').classList.remove('hidden');
    document.getElementById('teacher-id').value = '';
    document.getElementById('teacher-password').value = '';
    document.getElementById('student-roll').value = '';
    document.getElementById('student-password').value = '';
    document.getElementById('login-error').innerText = '';
    document.getElementById('teacher-msg').innerText = '';
    if (chartInstance) {
        chartInstance.destroy();
    }
}

async function addStudent(event) {
    if (event) event.preventDefault();
    
    // Basic Validation
    const roll = document.getElementById('roll').value.trim();
    const name = document.getElementById('name').value.trim();
    const dob = document.getElementById('dob').value;
    const phy = document.getElementById('phy').value;
    const chem = document.getElementById('chem').value;
    const math = document.getElementById('math').value;

    if (!roll || !name || !dob || !phy || !chem || !math) {
        document.getElementById('teacher-msg').innerText = 'Please fill all fields';
        document.getElementById('teacher-msg').style.color = 'red';
        return;
    }

    const student = {
        rollNo: roll,
        name: name,
        dateOfBirth: dob,
        physics: phy,
        chemistry: chem,
        math: math
    };

    try {
        const res = await fetch(`${API_URL}/add_student`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(student)
        });

        if (res.ok) {
            // Calculate password for display
            let pwd = "Unknown";
            if (dob && dob.length >= 10) {
                const yyyy = dob.substr(0, 4);
                const mm = dob.substr(5, 2);
                const dd = dob.substr(8, 2);
                pwd = dd + mm + yyyy;
            }

            document.getElementById('teacher-msg').innerHTML = `Student added successfully!<br><strong>Password: ${pwd}</strong>`;
            document.getElementById('teacher-msg').style.color = '#2ecc71';
            document.getElementById('add-student-form').reset();

            // Reload student list and statistics
            loadAllStudents();
            loadStatistics();
        } else {
            const data = await res.json();
            document.getElementById('teacher-msg').innerText = data.error || 'Error adding student.';
            document.getElementById('teacher-msg').style.color = 'red';
        }
    } catch (e) {
        console.error("Add student error:", e);
        document.getElementById('teacher-msg').innerText = 'Connection Error: Please try again later.';
        document.getElementById('teacher-msg').style.color = 'red';
    }
}

// Initialize Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Form submission is handled by onsubmit in HTML
});

async function loadAllStudents() {
    try {
        const res = await fetch(`${API_URL}/students/all`);
        const students = await res.json();

        const tbody = document.getElementById('students-tbody');

        if (students.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="no-data">No students added yet</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        students.forEach(s => {
            console.log("Rendering Row:", s);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${s.rollNo}</td>
                <td>${s.name}</td>
                <td>${s.physics !== undefined ? s.physics : '0'}</td>
                <td>${s.chemistry !== undefined ? s.chemistry : '0'}</td>
                <td>${s.math !== undefined ? s.math : '0'}</td>
                <td>${s.total}</td>
                <td>${parseFloat(s.percentage).toFixed(2)}%</td>
                <td><strong>${s.grade}</strong></td>
            `;
            tbody.appendChild(row);
        });
    } catch (e) {
        console.error('Error loading students:', e);
    }
}

let pfChart = null;
let gradeChart = null;

async function loadStatistics() {
    try {
        const res = await fetch(`${API_URL}/statistics`);
        const stats = await res.json();
        
        // Fetch all students to calculate chart data
        const studentsRes = await fetch(`${API_URL}/students/all`);
        const students = await studentsRes.json();

        document.getElementById('stat-total-students').innerText = stats.totalStudents;
        document.getElementById('stat-avg-percentage').innerText = parseFloat(stats.averagePercentage).toFixed(2) + '%';
        document.getElementById('stat-highest-scorer').innerText = stats.highestScorer;
        document.getElementById('stat-lowest-scorer').innerText = stats.lowestScorer;

        renderStatsCharts(students);
    } catch (e) {
        console.error('Error loading statistics:', e);
    }
}

function renderStatsCharts(students) {
    // Process data for charts
    let passCount = 0;
    let failCount = 0;
    const gradeCounts = { 'A': 0, 'B': 0, 'C': 0, 'D': 0, 'E': 0, 'F': 0 };

    console.log("Processing Students for Charts:", students);

    students.forEach(s => {
        // Consider all students for stats, even if total is 0 (they are failed)
        // Trim grade to avoid whitespace issues
        const grade = s.grade ? s.grade.trim() : 'F';
        
        if (grade === 'F') {
            failCount++;
        } else {
            passCount++;
        }
        
        if (gradeCounts[grade] !== undefined) {
            gradeCounts[grade]++;
        } else {
            // If grade is somehow not in the map (e.g. lower case), normalize it
            gradeCounts['F']++;
        }
    });

    console.log("Pass:", passCount, "Fail:", failCount);

    // Pass/Fail Pie Chart
    const pfCtx = document.getElementById('passFailChart').getContext('2d');
    if (pfChart) pfChart.destroy();
    pfChart = new Chart(pfCtx, {
        type: 'pie',
        data: {
            labels: ['Pass', 'Fail'],
            datasets: [{
                data: [passCount, failCount],
                backgroundColor: ['#2ecc71', '#e74c3c']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Pass vs Fail' }
            }
        }
    });

    // Grade Distribution Bar Chart
    const gCtx = document.getElementById('gradeDistributionChart').getContext('2d');
    if (gradeChart) gradeChart.destroy();
    gradeChart = new Chart(gCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(gradeCounts),
            datasets: [{
                label: 'Number of Students',
                data: Object.values(gradeCounts),
                backgroundColor: '#4a90e2'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Grade Distribution' }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

async function loadStudentData(rollNo) {
    try {
        const res = await fetch(`${API_URL}/student?rollNo=${rollNo}`);
        const data = await res.json();

        if (res.ok) {
            document.getElementById('st-name').innerText = data.name;
            document.getElementById('st-roll').innerText = data.rollNo;
            document.getElementById('st-grade').innerText = data.grade;

            document.getElementById('m-phy').innerText = data.physics;
            document.getElementById('m-chem').innerText = data.chemistry;
            document.getElementById('m-math').innerText = data.math;
            document.getElementById('m-total').innerText = data.total;
            document.getElementById('m-perc').innerText = parseFloat(data.percentage).toFixed(2) + '%';

            renderChart(data);
        }
    } catch (e) {
        console.error(e);
    }
}

function renderChart(data) {
    const ctx = document.getElementById('performanceChart').getContext('2d');

    if (chartInstance) {
        chartInstance.destroy();
    }

    chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Physics', 'Chemistry', 'Math'],
            datasets: [{
                label: 'Marks',
                data: [data.physics, data.chemistry, data.math],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}
