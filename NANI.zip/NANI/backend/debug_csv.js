const fs = require('fs');
const path = require('path');

const STUDENTS_FILE = path.join(__dirname, 'students.csv');

function calculateGrade(percentage) {
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    if (percentage >= 40) return 'E';
    return 'F';
}

function processStudent(s) {
    console.log("Raw student before processing:", s);
    s.physics = parseInt(s.physics);
    s.chemistry = parseInt(s.chemistry);
    s.math = parseInt(s.math);
    console.log("Parsed marks:", s.physics, s.chemistry, s.math);
    s.total = s.physics + s.chemistry + s.math;
    s.percentage = s.total / 3.0;
    s.grade = calculateGrade(s.percentage);
    return s;
}

function loadData() {
    if (fs.existsSync(STUDENTS_FILE)) {
        const data = fs.readFileSync(STUDENTS_FILE, 'utf8');
        console.log("File content:", JSON.stringify(data));
        const students = [];
        data.split('\n').forEach(line => {
            if (line.trim()) {
                const parts = line.split(',');
                if (parts.length >= 6) {
                    const s = {
                        rollNo: parts[0],
                        name: parts[1],
                        dateOfBirth: parts[2],
                        physics: parts[3],
                        chemistry: parts[4],
                        math: parts[5]
                    };
                    students.push(processStudent(s));
                }
            }
        });
        console.log("Final Students Array:", JSON.stringify(students, null, 2));
    } else {
        console.log("File not found");
    }
}

loadData();