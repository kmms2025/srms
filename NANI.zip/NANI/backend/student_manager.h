#ifndef STUDENT_MANAGER_H
#define STUDENT_MANAGER_H

#include <string>
#include <vector>
#include <map>

struct Student {
    std::string rollNo;
    std::string name;
    std::string dateOfBirth; // Format: YYYY-MM-DD
    int physics;
    int chemistry;
    int math;
    int total;
    char grade;
    float percentage;
    
    // Helper to get password from DOB (DDMMYYYY format)
    std::string getPassword() const;
};

struct Teacher {
    std::string teacherId;
    std::string password;
};

struct ClassStatistics {
    float averagePercentage;
    std::string highestScorer;
    float highestPercentage;
    std::string lowestScorer;
    float lowestPercentage;
    int totalStudents;
};

class StudentManager {
public:
    void addStudent(const Student& student);
    Student* getStudent(const std::string& rollNo);
    std::vector<Student> getAllStudents() const;
    void calculateStats(Student& student);
    ClassStatistics getClassStatistics() const;
    
    static char calculateGrade(float percentage);

private:
    std::map<std::string, Student> students;
};

class TeacherManager {
public:
    void addTeacher(const Teacher& teacher);
    Teacher* getTeacher(const std::string& teacherId);
    bool authenticate(const std::string& teacherId, const std::string& password);

private:
    std::map<std::string, Teacher> teachers;
};

#endif // STUDENT_MANAGER_H

