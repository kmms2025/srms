#include "file_handler.h"
#include <fstream>
#include <sstream>
#include <iostream>

void FileHandler::saveToFile(const std::string& filename, const std::vector<Student>& students) {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::cerr << "Error opening file for writing: " << filename << std::endl;
        return;
    }

    for (const auto& s : students) {
        outFile << s.rollNo << "," << s.name << "," << s.dateOfBirth << "," 
                << s.physics << "," << s.chemistry << "," << s.math << "\n";
    }
    outFile.close();
}

void FileHandler::loadFromFile(const std::string& filename, StudentManager& manager) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        // It's okay if file doesn't exist yet
        return;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        std::stringstream ss(line);
        std::string segment;
        std::vector<std::string> parts;

        while (std::getline(ss, segment, ',')) {
            parts.push_back(segment);
        }

        if (parts.size() >= 6) {
            Student s;
            s.rollNo = parts[0];
            s.name = parts[1];
            s.dateOfBirth = parts[2];
            s.physics = std::stoi(parts[3]);
            s.chemistry = std::stoi(parts[4]);
            s.math = std::stoi(parts[5]);
            manager.addStudent(s);
        }
    }
    inFile.close();
}

void FileHandler::saveTeachersToFile(const std::string& filename, const std::vector<Teacher>& teachers) {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::cerr << "Error opening file for writing: " << filename << std::endl;
        return;
    }

    for (const auto& t : teachers) {
        outFile << t.teacherId << "," << t.password << "\n";
    }
    outFile.close();
}

void FileHandler::loadTeachersFromFile(const std::string& filename, TeacherManager& manager) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        // Create default teacher if file doesn't exist
        Teacher defaultTeacher;
        defaultTeacher.teacherId = "T001";
        defaultTeacher.password = "admin";
        manager.addTeacher(defaultTeacher);
        return;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        std::stringstream ss(line);
        std::string segment;
        std::vector<std::string> parts;

        while (std::getline(ss, segment, ',')) {
            parts.push_back(segment);
        }

        if (parts.size() >= 2) {
            Teacher t;
            t.teacherId = parts[0];
            t.password = parts[1];
            manager.addTeacher(t);
        }
    }
    inFile.close();
}
