const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 8080;
const STUDENTS_FILE = path.join(__dirname, 'students.csv');
const TEACHERS_FILE = path.join(__dirname, 'teachers.csv');

let students = [];
let teachers = [];

// --- Data Models & Helpers ---

function calculateGrade(percentage) {
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    if (percentage >= 40) return 'E';
    return 'F';
}

function processStudent(s) {
    s.physics = parseInt(s.physics);
    s.chemistry = parseInt(s.chemistry);
    s.math = parseInt(s.math);
    s.total = s.physics + s.chemistry + s.math;
    s.percentage = s.total / 3.0;
    s.grade = calculateGrade(s.percentage);
    return s;
}

function getPassword(dateOfBirth) {
    // Convert YYYY-MM-DD to DDMMYYYY
    if (dateOfBirth && dateOfBirth.length >= 10) {
        const yyyy = dateOfBirth.substr(0, 4);
        const mm = dateOfBirth.substr(5, 2);
        const dd = dateOfBirth.substr(8, 2);
        return dd + mm + yyyy;
    }
    return "01011900";
}

function loadData() {
    // Load Students
    if (fs.existsSync(STUDENTS_FILE)) {
        const data = fs.readFileSync(STUDENTS_FILE, 'utf8');
        students = [];
        data.split('\n').forEach(line => {
            if (line.trim()) {
                const parts = line.split(',');
                if (parts.length >= 6) {
                    const s = {
                        rollNo: parts[0],
                        name: parts[1],
                        dateOfBirth: parts[2],
                        physics: parts[3],
                        chemistry: parts[4],
                        math: parts[5]
                    };
                    students.push(processStudent(s));
                }
            }
        });
    }

    // Load Teachers
    if (fs.existsSync(TEACHERS_FILE)) {
        const data = fs.readFileSync(TEACHERS_FILE, 'utf8');
        teachers = [];
        data.split('\n').forEach(line => {
            if (line.trim()) {
                const parts = line.split(',');
                if (parts.length >= 2) {
                    teachers.push({
                        teacherId: parts[0],
                        password: parts[1]
                    });
                }
            }
        });
    } else {
        // Default teacher
        teachers.push({ teacherId: "T001", password: "admin" });
    }
}

function saveData() {
    const studentData = students.map(s => 
        `${s.rollNo},${s.name},${s.dateOfBirth},${s.physics},${s.chemistry},${s.math}`
    ).join('\n');
    fs.writeFileSync(STUDENTS_FILE, studentData);

    const teacherData = teachers.map(t => 
        `${t.teacherId},${t.password}`
    ).join('\n');
    fs.writeFileSync(TEACHERS_FILE, teacherData);
}

loadData();

// --- Server ---

const server = http.createServer((req, res) => {
    // CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;

    console.log(`${req.method} ${pathname}`);

    if (req.method === 'GET') {
        if (pathname === '/' || pathname === '/index.html') {
            serveStatic(res, '../frontend/index.html', 'text/html');
        } else if (pathname === '/style.css') {
            serveStatic(res, '../frontend/style.css', 'text/css');
        } else if (pathname === '/app.js') {
            serveStatic(res, '../frontend/app.js', 'application/javascript');
        } else if (pathname === '/api/students/all') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(students));
        } else if (pathname.startsWith('/api/student')) {
            // /api/student?rollNo=123
            const rollNo = parsedUrl.query.rollNo;
            if (rollNo) {
                const s = students.find(stu => stu.rollNo === rollNo);
                if (s) {
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify(s));
                } else {
                    res.writeHead(404, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: "Student not found" }));
                }
            } else {
                // Return simple list
                const list = students.map(s => ({
                    rollNo: s.rollNo,
                    name: s.name,
                    total: s.total,
                    grade: s.grade
                }));
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(list));
            }
        } else if (pathname === '/api/statistics') {
            const stats = {
                totalStudents: students.length,
                averagePercentage: 0,
                highestScorer: "N/A",
                highestPercentage: 0,
                lowestScorer: "N/A",
                lowestPercentage: 0
            };

                const validStudents = students.filter(s => s.total > 0); // Only consider graded students

                if (validStudents.length > 0) {
                    let sum = 0;
                    let highest = -1;
                    let lowest = 101;

                    validStudents.forEach(s => {
                        sum += s.percentage;
                        if (s.percentage > highest) {
                            highest = s.percentage;
                            stats.highestScorer = s.name;
                            stats.highestPercentage = s.percentage;
                        }
                        if (s.percentage < lowest) {
                            lowest = s.percentage;
                            stats.lowestScorer = s.name;
                            stats.lowestPercentage = s.percentage;
                        }
                    });
                    stats.averagePercentage = sum / validStudents.length;
                }
                // If no graded students, leave as default (0/NA)
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(stats));
        } else {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('Not Found');
        }
    } else if (req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                
                if (pathname === '/api/add_student') {
                    // Check if student exists, if so update marks
                    const existingIndex = students.findIndex(stu => stu.rollNo === data.rollNo);
                    
                    const s = {
                        rollNo: data.rollNo,
                        name: data.name,
                        dateOfBirth: data.dateOfBirth || (existingIndex !== -1 ? students[existingIndex].dateOfBirth : "1900-01-01"),
                        physics: data.physics,
                        chemistry: data.chemistry,
                        math: data.math
                    };

                    if (existingIndex !== -1) {
                        students[existingIndex] = processStudent(s);
                    } else {
                        students.push(processStudent(s));
                    }
                    
                    saveData();
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ status: "success" }));

                } else if (pathname === '/api/login') {
                    if (data.role === 'teacher') {
                        const t = teachers.find(tch => tch.teacherId === data.teacherId && tch.password === data.password);
                        if (t) {
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.end(JSON.stringify({ status: "success", role: "teacher", teacherId: t.teacherId }));
                        } else {
                            res.writeHead(401, { 'Content-Type': 'application/json' });
                            res.end(JSON.stringify({ error: "Invalid Teacher ID or Password" }));
                        }
                    } else if (data.role === 'student') {
                        const s = students.find(stu => stu.rollNo === data.rollNo);
                        
                        console.log(`Login Attempt - Roll: ${data.rollNo}, Input Pwd: ${data.password}`);
                        if (s) {
                            const generatedPwd = getPassword(s.dateOfBirth);
                            console.log(`Found Student: ${s.name}, DOB: ${s.dateOfBirth}, Expected Pwd: ${generatedPwd}`);
                            
                            if (generatedPwd === data.password) {
                                res.writeHead(200, { 'Content-Type': 'application/json' });
                                res.end(JSON.stringify({ status: "success", role: "student", rollNo: s.rollNo }));
                            } else {
                                res.writeHead(401, { 'Content-Type': 'application/json' });
                                res.end(JSON.stringify({ error: "Invalid Password" }));
                            }
                        } else {
                            console.log("Student not found");
                            res.writeHead(401, { 'Content-Type': 'application/json' });
                            res.end(JSON.stringify({ error: "Invalid Roll Number" }));
                        }
                    } else {
                        res.writeHead(401, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ error: "Invalid Credentials" }));
                    }

                } else if (pathname === '/api/register_teacher') {
                    teachers.push({
                        teacherId: data.teacherId,
                        password: data.password
                    });
                    saveData();
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ status: "success", message: "Teacher registered successfully" }));

                } else if (pathname === '/api/register_student') {
                     const s = {
                        rollNo: data.rollNo,
                        name: data.name,
                        dateOfBirth: data.dateOfBirth,
                        physics: data.physics || 0,
                        chemistry: data.chemistry || 0,
                        math: data.math || 0
                    };
                    students.push(processStudent(s));
                    saveData();
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ status: "success", message: "Student registered successfully" }));
                } else {
                    res.writeHead(404);
                    res.end();
                }
            } catch (e) {
                console.error(e);
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: "Invalid JSON" }));
            }
        });
    }
});

function serveStatic(res, relativePath, contentType) {
    const filePath = path.join(__dirname, relativePath);
    fs.readFile(filePath, (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                res.writeHead(404);
                res.end('File not found');
            } else {
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
}

server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});
