#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <thread>
#include "student_manager.h"
#include "file_handler.h"

#pragma comment(lib, "ws2_32.lib")

#define PORT 8080
#define BUFFER_SIZE 4096

StudentManager studentManager;
TeacherManager teacherManager;
const std::string DATA_FILE = "students.csv";
const std::string TEACHER_FILE = "teachers.csv";

// Helper to read file content
std::string readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) return "";
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Helper to send response
void sendResponse(SOCKET clientSocket, const std::string& status, const std::string& contentType, const std::string& body) {
    std::string response = "HTTP/1.1 " + status + "\r\n"
                           "Content-Type: " + contentType + "\r\n"
                           "Content-Length: " + std::to_string(body.size()) + "\r\n"
                           "Access-Control-Allow-Origin: *\r\n"
                           "\r\n" + body;
    send(clientSocket, response.c_str(), response.size(), 0);
}

// Parse query parameters
std::map<std::string, std::string> parseQuery(const std::string& query) {
    std::map<std::string, std::string> params;
    std::stringstream ss(query);
    std::string segment;
    while (std::getline(ss, segment, '&')) {
        size_t pos = segment.find('=');
        if (pos != std::string::npos) {
            params[segment.substr(0, pos)] = segment.substr(pos + 1);
        }
    }
    return params;
}

// Parse JSON body (very basic manual parser for this specific use case)
std::map<std::string, std::string> parseJson(const std::string& body) {
    std::map<std::string, std::string> data;
    // Remove braces and whitespace
    std::string clean = body;
    // This is a hacky parser. In a real app, use a library like nlohmann/json
    // Expecting: {"rollNo":"123", "name":"John", ...}
    size_t pos = 0;
    while ((pos = clean.find('"', pos)) != std::string::npos) {
        size_t endKey = clean.find('"', pos + 1);
        std::string key = clean.substr(pos + 1, endKey - pos - 1);
        
        size_t startVal = clean.find(':', endKey);
        size_t valQuoteStart = clean.find('"', startVal);
        size_t valQuoteEnd = clean.find('"', valQuoteStart + 1);
        
        // Handle numbers (no quotes)
        if (valQuoteStart == std::string::npos || (clean.find(',', startVal) < valQuoteStart && clean.find(',', startVal) != std::string::npos)) {
             // It's a number or boolean
             size_t endVal = clean.find_first_of(",}", startVal);
             std::string val = clean.substr(startVal + 1, endVal - startVal - 1);
             // Trim whitespace
             val.erase(0, val.find_first_not_of(" \t\n\r"));
             val.erase(val.find_last_not_of(" \t\n\r") + 1);
             data[key] = val;
             pos = endVal;
        } else {
            // It's a string
            std::string val = clean.substr(valQuoteStart + 1, valQuoteEnd - valQuoteStart - 1);
            data[key] = val;
            pos = valQuoteEnd + 1;
        }
    }
    return data;
}

void handleClient(SOCKET clientSocket) {
    char buffer[BUFFER_SIZE];
    int bytesReceived = recv(clientSocket, buffer, BUFFER_SIZE, 0);
    if (bytesReceived <= 0) {
        closesocket(clientSocket);
        return;
    }

    std::string request(buffer, bytesReceived);
    std::istringstream requestStream(request);
    std::string method, path, protocol;
    requestStream >> method >> path >> protocol;

    std::cout << method << " " << path << std::endl;

    if (method == "GET") {
        if (path == "/" || path == "/index.html") {
            std::string content = readFile("../frontend/index.html");
            sendResponse(clientSocket, "200 OK", "text/html", content);
        } else if (path == "/style.css") {
            std::string content = readFile("../frontend/style.css");
            sendResponse(clientSocket, "200 OK", "text/css", content);
        } else if (path == "/app.js") {
            std::string content = readFile("../frontend/app.js");
            sendResponse(clientSocket, "200 OK", "application/javascript", content);
        } else if (path.find("/api/student") == 0) {
            // /api/student?rollNo=123
            size_t qPos = path.find('?');
            if (qPos != std::string::npos) {
                auto params = parseQuery(path.substr(qPos + 1));
                if (params.count("rollNo")) {
                    Student* s = studentManager.getStudent(params["rollNo"]);
                    if (s) {
                        std::string json = "{";
                        json += "\"rollNo\":\"" + s->rollNo + "\",";
                        json += "\"name\":\"" + s->name + "\",";
                        json += "\"physics\":" + std::to_string(s->physics) + ",";
                        json += "\"chemistry\":" + std::to_string(s->chemistry) + ",";
                        json += "\"math\":" + std::to_string(s->math) + ",";
                        json += "\"total\":" + std::to_string(s->total) + ",";
                        json += "\"percentage\":" + std::to_string(s->percentage) + ",";
                        json += "\"grade\":\"" + std::string(1, s->grade) + "\"";
                        json += "}";
                        sendResponse(clientSocket, "200 OK", "application/json", json);
                    } else {
                        sendResponse(clientSocket, "404 Not Found", "application/json", "{\"error\":\"Student not found\"}");
                    }
                } else {
                    sendResponse(clientSocket, "400 Bad Request", "application/json", "{\"error\":\"Missing rollNo\"}");
                }
            } else {
                 // Return all students
                 auto students = studentManager.getAllStudents();
                 std::string json = "[";
                 for (size_t i = 0; i < students.size(); ++i) {
                     const auto& s = students[i];
                     json += "{";
                     json += "\"rollNo\":\"" + s.rollNo + "\",";
                     json += "\"name\":\"" + s.name + "\",";
                     json += "\"total\":" + std::to_string(s.total) + ",";
                     json += "\"grade\":\"" + std::string(1, s.grade) + "\"";
                     json += "}";
                     if (i < students.size() - 1) json += ",";
                 }
                 json += "]";
                 sendResponse(clientSocket, "200 OK", "application/json", json);
            }
        } else if (path == "/api/students/all") {
            // Return all students with full details
            auto students = studentManager.getAllStudents();
            std::string json = "[";
            for (size_t i = 0; i < students.size(); ++i) {
                const auto& s = students[i];
                json += "{";
                json += "\"rollNo\":\"" + s.rollNo + "\",";
                json += "\"name\":\"" + s.name + "\",";
                json += "\"physics\":" + std::to_string(s.physics) + ",";
                json += "\"chemistry\":" + std::to_string(s.chemistry) + ",";
                json += "\"math\":" + std::to_string(s.math) + ",";
                json += "\"total\":" + std::to_string(s.total) + ",";
                json += "\"percentage\":" + std::to_string(s.percentage) + ",";
                json += "\"grade\":\"" + std::string(1, s.grade) + "\"";
                json += "}";
                if (i < students.size() - 1) json += ",";
            }
            json += "]";
            sendResponse(clientSocket, "200 OK", "application/json", json);
        } else if (path == "/api/statistics") {
            // Return class statistics
            auto stats = studentManager.getClassStatistics();
            std::string json = "{";
            json += "\"totalStudents\":" + std::to_string(stats.totalStudents) + ",";
            json += "\"averagePercentage\":" + std::to_string(stats.averagePercentage) + ",";
            json += "\"highestScorer\":\"" + stats.highestScorer + "\",";
            json += "\"highestPercentage\":" + std::to_string(stats.highestPercentage) + ",";
            json += "\"lowestScorer\":\"" + stats.lowestScorer + "\",";
            json += "\"lowestPercentage\":" + std::to_string(stats.lowestPercentage);
            json += "}";
            sendResponse(clientSocket, "200 OK", "application/json", json);
        } else {
            sendResponse(clientSocket, "404 Not Found", "text/plain", "Not Found");
        }
    } else if (method == "POST") {
        // Find body
        size_t bodyPos = request.find("\r\n\r\n");
        if (bodyPos != std::string::npos) {
            std::string body = request.substr(bodyPos + 4);
            
            if (path == "/api/add_student") {
                auto data = parseJson(body);
                Student s;
                s.rollNo = data["rollNo"];
                s.name = data["name"];
                s.dateOfBirth = data.count("dateOfBirth") ? data["dateOfBirth"] : "1900-01-01";
                s.physics = std::stoi(data["physics"]);
                s.chemistry = std::stoi(data["chemistry"]);
                s.math = std::stoi(data["math"]);
                
                studentManager.addStudent(s);
                FileHandler::saveToFile(DATA_FILE, studentManager.getAllStudents());
                
                sendResponse(clientSocket, "200 OK", "application/json", "{\"status\":\"success\"}");
            } else if (path == "/api/login") {
                auto data = parseJson(body);
                if (data["role"] == "teacher") {
                     if (teacherManager.authenticate(data["teacherId"], data["password"])) {
                         sendResponse(clientSocket, "200 OK", "application/json", "{\"status\":\"success\", \"role\":\"teacher\", \"teacherId\":\"" + data["teacherId"] + "\"}");
                     } else {
                         sendResponse(clientSocket, "401 Unauthorized", "application/json", "{\"error\":\"Invalid Teacher ID or Password\"}");
                     }
                } else if (data["role"] == "student") {
                     Student* s = studentManager.getStudent(data["rollNo"]);
                     if (s && s->getPassword() == data["password"]) {
                         sendResponse(clientSocket, "200 OK", "application/json", "{\"status\":\"success\", \"role\":\"student\", \"rollNo\":\"" + data["rollNo"] + "\"}");
                     } else {
                         sendResponse(clientSocket, "401 Unauthorized", "application/json", "{\"error\":\"Invalid Roll Number or Password\"}");
                     }
                } else {
                    sendResponse(clientSocket, "401 Unauthorized", "application/json", "{\"error\":\"Invalid Credentials\"}");
                }
            } else if (path == "/api/register_teacher") {
                auto data = parseJson(body);
                Teacher t;
                t.teacherId = data["teacherId"];
                t.password = data["password"];
                teacherManager.addTeacher(t);
                
                // Save to file
                std::vector<Teacher> teachers;
                // Note: We'd need to add a getAllTeachers method to save properly
                // For now, just add the new teacher
                FileHandler::saveTeachersToFile(TEACHER_FILE, teachers);
                
                sendResponse(clientSocket, "200 OK", "application/json", "{\"status\":\"success\", \"message\":\"Teacher registered successfully\"}");
            } else if (path == "/api/register_student") {
                auto data = parseJson(body);
                Student s;
                s.rollNo = data["rollNo"];
                s.name = data["name"];
                s.dateOfBirth = data["dateOfBirth"];
                s.physics = std::stoi(data["physics"]);
                s.chemistry = std::stoi(data["chemistry"]);
                s.math = std::stoi(data["math"]);
                
                studentManager.addStudent(s);
                FileHandler::saveToFile(DATA_FILE, studentManager.getAllStudents());
                
                sendResponse(clientSocket, "200 OK", "application/json", "{\"status\":\"success\", \"message\":\"Student registered successfully. Password is DOB in DDMMYYYY format\"}");
            }
        }
    }

    closesocket(clientSocket);
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed" << std::endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Socket creation failed" << std::endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        std::cerr << "Listen failed" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Load initial data
    FileHandler::loadFromFile(DATA_FILE, studentManager);
    FileHandler::loadTeachersFromFile(TEACHER_FILE, teacherManager);

    std::cout << "Server started on port " << PORT << std::endl;

    while (true) {
        SOCKET clientSocket = accept(serverSocket, nullptr, nullptr);
        if (clientSocket == INVALID_SOCKET) {
            std::cerr << "Accept failed" << std::endl;
            continue;
        }
        
        // Handle in a thread to allow multiple connections (though simple implementation)
        std::thread(handleClient, clientSocket).detach();
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
