#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include "student_manager.h"
#include <string>
#include <vector>

class FileHandler {
public:
    static void saveToFile(const std::string& filename, const std::vector<Student>& students);
    static void loadFromFile(const std::string& filename, StudentManager& manager);
    
    static void saveTeachersToFile(const std::string& filename, const std::vector<Teacher>& teachers);
    static void loadTeachersFromFile(const std::string& filename, TeacherManager& manager);
};

#endif // FILE_HANDLER_H
