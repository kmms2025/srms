#include "student_manager.h"
#include <iostream>
#include <limits>

// Student::getPassword implementation
std::string Student::getPassword() const {
    // Convert YYYY-MM-DD to DDMMYYYY
    if (dateOfBirth.length() >= 10) {
        std::string dd = dateOfBirth.substr(8, 2);
        std::string mm = dateOfBirth.substr(5, 2);
        std::string yyyy = dateOfBirth.substr(0, 4);
        return dd + mm + yyyy;
    }
    return "01011900"; // Default if invalid
}

void StudentManager::addStudent(const Student& student) {
    Student s = student;
    calculateStats(s);
    students[s.rollNo] = s;
}

Student* StudentManager::getStudent(const std::string& rollNo) {
    if (students.find(rollNo) != students.end()) {
        return &students[rollNo];
    }
    return nullptr;
}

std::vector<Student> StudentManager::getAllStudents() const {
    std::vector<Student> allStudents;
    for (const auto& pair : students) {
        allStudents.push_back(pair.second);
    }
    return allStudents;
}

void StudentManager::calculateStats(Student& student) {
    student.total = student.physics + student.chemistry + student.math;
    student.percentage = student.total / 3.0f;
    student.grade = calculateGrade(student.percentage);
}

char StudentManager::calculateGrade(float percentage) {
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    if (percentage >= 40) return 'E';
    return 'F';
}

ClassStatistics StudentManager::getClassStatistics() const {
    ClassStatistics stats;
    stats.totalStudents = students.size();
    
    if (students.empty()) {
        stats.averagePercentage = 0;
        stats.highestPercentage = 0;
        stats.lowestPercentage = 0;
        stats.highestScorer = "N/A";
        stats.lowestScorer = "N/A";
        return stats;
    }
    
    float sum = 0;
    float highest = -1;
    float lowest = std::numeric_limits<float>::max();
    
    for (const auto& pair : students) {
        const Student& s = pair.second;
        sum += s.percentage;
        
        if (s.percentage > highest) {
            highest = s.percentage;
            stats.highestScorer = s.name;
            stats.highestPercentage = s.percentage;
        }
        
        if (s.percentage < lowest) {
            lowest = s.percentage;
            stats.lowestScorer = s.name;
            stats.lowestPercentage = s.percentage;
        }
    }
    
    stats.averagePercentage = sum / students.size();
    return stats;
}

// TeacherManager implementation
void TeacherManager::addTeacher(const Teacher& teacher) {
    teachers[teacher.teacherId] = teacher;
}

Teacher* TeacherManager::getTeacher(const std::string& teacherId) {
    if (teachers.find(teacherId) != teachers.end()) {
        return &teachers[teacherId];
    }
    return nullptr;
}

bool TeacherManager::authenticate(const std::string& teacherId, const std::string& password) {
    Teacher* teacher = getTeacher(teacherId);
    if (teacher && teacher->password == password) {
        return true;
    }
    return false;
}
